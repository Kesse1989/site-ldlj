export async function onRequestGet(context) {
  const reference = String(new URL(context.request.url).searchParams.get("reference") || "").trim().toUpperCase();
  if (!reference) return Response.json({error:"Référence obligatoire."}, {status:400});

  const row = await context.env.DB.prepare(
    `SELECT reference,name,program,score,status,published_at
     FROM results WHERE reference=? LIMIT 1`
  ).bind(reference).first();

  if (!row) return Response.json({error:"Aucun résultat trouvé pour cette référence."}, {status:404});

  return Response.json(row);
}
