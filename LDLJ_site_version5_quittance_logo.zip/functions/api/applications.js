export async function onRequestPost(context) {
  try {
    const body = await context.request.json();
    const nom = String(body.nom || "").trim();
    const telephone = String(body.telephone || "").trim();
    const email = String(body.email || "").trim();
    const programme = String(body.programme || "").trim();

    if (!nom || !telephone || !email || !programme) {
      return Response.json({error:"Veuillez remplir tous les champs obligatoires."}, {status:400});
    }

    const reference = await uniqueReference(context.env.DB);
    await context.env.DB.prepare(
      `INSERT INTO applications (reference, nom, telephone, email, programme)
       VALUES (?, ?, ?, ?, ?)`
    ).bind(reference, nom, telephone, email, programme).run();

    return Response.json({
      ok:true,
      reference,
      notification_email: context.env.LDLJ_CONTACT_EMAIL || "ldljassociation@gmail.com"
    });
  } catch (e) {
    return Response.json({error:"Erreur serveur lors de l'enregistrement."}, {status:500});
  }
}

async function uniqueReference(envDB) {
  for (let i=0; i<10; i++) {
    const reference = `LDLJ-${new Date().getFullYear()}-${Math.floor(100000 + Math.random()*900000)}`;
    const row = await envDB.prepare("SELECT id FROM applications WHERE reference=?").bind(reference).first();
    if (!row) return reference;
  }
  throw new Error("Impossible de générer une référence unique.");
}
