export async function onRequestPost(context) {
  try {
    const body = await context.request.json();
    const nom = String(body.nom || "").trim();
    const email = String(body.email || "").trim();
    const telephone = String(body.telephone || "").trim();
    const sujet = String(body.sujet || "").trim();
    const message = String(body.message || "").trim();

    if (!nom || !email || !message) {
      return Response.json({error:"Nom, e-mail et message sont obligatoires."}, {status:400});
    }

    await context.env.DB.prepare(
      `INSERT INTO contact_messages (nom,email,telephone,sujet,message)
       VALUES (?, ?, ?, ?, ?)`
    ).bind(nom,email,telephone,sujet,message).run();

    return Response.json({
      ok:true,
      notification_email: context.env.LDLJ_CONTACT_EMAIL || "ldljassociation@gmail.com"
    });
  } catch (e) {
    return Response.json({error:"Erreur serveur lors de l'enregistrement du message."}, {status:500});
  }
}
