function authorized(request, env) {
  const token = request.headers.get("X-Admin-Token") || "";
  return !!env.ADMIN_TOKEN && token === env.ADMIN_TOKEN;
}

export async function onRequestGet(context) {
  if (!authorized(context.request, context.env)) return Response.json({error:"Accès refusé."},{status:401});
  const apps = await context.env.DB.prepare(
    "SELECT reference,nom,telephone,email,programme,status,created_at FROM applications ORDER BY id DESC LIMIT 500"
  ).all();
  const contacts = await context.env.DB.prepare(
    "SELECT id,nom,email,telephone,sujet,message,created_at FROM contact_messages ORDER BY id DESC LIMIT 500"
  ).all();
  const results = await context.env.DB.prepare(
    "SELECT reference,name,program,score,status,published_at FROM results ORDER BY id DESC LIMIT 500"
  ).all();
  return Response.json({applications:apps.results,contacts:contacts.results,results:results.results});
}

export async function onRequestPost(context) {
  if (!authorized(context.request, context.env)) return Response.json({error:"Accès refusé."},{status:401});
  const body = await context.request.json();
  const reference = String(body.reference || "").trim().toUpperCase();
  const name = String(body.name || "").trim();
  const program = String(body.program || "").trim();
  const score = body.score === "" || body.score == null ? null : Number(body.score);
  const status = String(body.status || "").trim();

  if (!reference || !name || !status) {
    return Response.json({error:"Référence, nom et statut sont obligatoires."},{status:400});
  }

  await context.env.DB.prepare(
    `INSERT INTO results(reference,name,program,score,status)
     VALUES(?,?,?,?,?)
     ON CONFLICT(reference) DO UPDATE SET
       name=excluded.name, program=excluded.program, score=excluded.score,
       status=excluded.status, published_at=CURRENT_TIMESTAMP`
  ).bind(reference,name,program,score,status).run();

  return Response.json({ok:true});
}
