LDLJ — VERSION 4 PROFESSIONNELLE / NETLIFY

Cette version ajoute :
- menu complet : Accueil, À propos, Programmes, Activités, Projets, Actualités, Galerie, Candidature, Résultats, Devenir membre, Soutenir LDLJ, Contact ;
- candidature avec référence unique générée côté serveur ;
- enregistrement des candidatures et messages dans Netlify Blobs ;
- espace résultats ;
- tableau de bord admin protégé par ADMIN_TOKEN ;
- publication/mise à jour de résultats ;
- demande d'adhésion ;
- contact connecté au backend.

DÉPLOIEMENT :
1. Cette version doit être déployée via Git (GitHub/GitLab/Bitbucket) ou Netlify CLI afin que Netlify construise les Functions. Un simple glisser-déposer Netlify Drop ne suffit pas pour activer le backend.
2. Dans Netlify, connecter le dépôt Git et déployer.
3. Dans Site configuration > Environment variables, créer ADMIN_TOKEN avec une valeur longue et secrète.
4. Netlify Blobs est utilisé pour le stockage. Ne jamais mettre le jeton dans le code public.
5. Après déploiement, tester /, /candidature, /resultats et /admin.html.

E-MAIL : ldljassociation@gmail.com
DOMAINE CIBLE : www.leaderdelajeunesse.ci

IMPORTANT :
- Cette version ne nécessite pas le mot de passe Gmail.
- L'envoi d'e-mails automatiques au candidat pourra être ajouté ensuite avec un fournisseur transactionnel.
- Pour un niveau de sécurité encore plus élevé, on pourra remplacer ADMIN_TOKEN par une authentification avec rôles.
