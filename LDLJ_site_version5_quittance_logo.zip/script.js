const API_BASE = '/api';
function toggleMenu(){ document.getElementById('menu')?.classList.toggle('open'); }
function closeMenu(){ document.getElementById('menu')?.classList.remove('open'); }
function escapeHtml(value){ return String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function showReceipt(targetId, data, type='Candidature'){
 const target=document.getElementById(targetId); if(!target) return;
 target.hidden=false;
 target.innerHTML=`<button type="button" class="btn outline" onclick='printReceipt(${JSON.stringify(data).replace(/'/g, '&#39;')}, ${JSON.stringify(type)})'>Imprimer le récépissé</button>`;
}
function printReceipt(data, type){
 const box=document.getElementById('printReceipt');
 const date=new Date().toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'});
 box.innerHTML=`<div class="receipt-sheet"><div class="receipt-header"><img src="assets/logo-ldlj.jpg" alt="Logo LDLJ"><div><h1>LEADER DE LA JEUNESSE</h1><p>Association LDLJ — Côte d'Ivoire</p><p>ldljassociation@gmail.com</p></div></div><hr><h2>RÉCÉPISSÉ D'ENREGISTREMENT</h2><p class="receipt-type">${escapeHtml(type)}</p><div class="receipt-ref">Référence : <strong>${escapeHtml(data.reference)}</strong></div><table><tr><th>Nom et prénoms</th><td>${escapeHtml(data.nom)}</td></tr><tr><th>Téléphone / WhatsApp</th><td>${escapeHtml(data.telephone)}</td></tr><tr><th>E-mail</th><td>${escapeHtml(data.email)}</td></tr><tr><th>Programme / activité</th><td>${escapeHtml(data.programme || data.activite || '—')}</td></tr><tr><th>Date d'enregistrement</th><td>${date}</td></tr><tr><th>Statut</th><td>Enregistré — en attente de traitement</td></tr></table><p class="receipt-note">Ce document atteste de l'enregistrement de la demande auprès de LDLJ. Il ne constitue pas une preuve de paiement tant qu'un paiement n'a pas été enregistré par LDLJ.</p><div class="receipt-sign"><span>Signature / Cachet LDLJ</span><span>Le demandeur</span></div></div>`;
 window.print();
}
async function submitCandidate(event){
 event.preventDefault(); const form=event.currentTarget, msg=document.getElementById('candidateMsg'); const data=Object.fromEntries(new FormData(form).entries()); msg.textContent='Enregistrement en cours…';
 try{ const r=await fetch(`${API_BASE}/applications`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); const o=await r.json(); if(!r.ok) throw new Error(o.error); data.reference=o.reference; msg.innerHTML=`<strong>Candidature enregistrée.</strong><br>Votre référence : <strong>${escapeHtml(o.reference)}</strong><br>Conservez-la précieusement.`; showReceipt('candidateReceipt',data,'Candidature à un programme'); form.reset(); }catch(e){ msg.textContent=e.message||'Erreur.'; }
}
async function checkResult(event){
 event.preventDefault(); const ref=document.getElementById('reference').value.trim().toUpperCase(), box=document.getElementById('resultBox'); box.textContent='Vérification en cours…';
 try{ const r=await fetch(`${API_BASE}/results?reference=${encodeURIComponent(ref)}`); const o=await r.json(); if(!r.ok) throw new Error(o.error); box.innerHTML=`<div class="result-card"><h3>${escapeHtml(o.status||'Résultat disponible')}</h3><p><b>Référence :</b> ${escapeHtml(o.reference)}</p><p><b>Nom :</b> ${escapeHtml(o.name||'—')}</p><p><b>Programme :</b> ${escapeHtml(o.program||'—')}</p><p><b>Score :</b> ${escapeHtml(o.score||'—')}</p><p><b>Date de publication :</b> ${escapeHtml(o.published_at||'—')}</p><button class="btn" onclick="window.print()">Imprimer</button></div>`; }catch(e){ box.innerHTML=`<p class="notice">${escapeHtml(e.message||'Résultat introuvable.')}</p>`; }
}
async function submitContact(event){
 event.preventDefault(); const form=event.currentTarget,msg=document.getElementById('contactMsg'); msg.textContent='Envoi en cours…';
 try{ const r=await fetch(`${API_BASE}/contact`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(form).entries()))}); const o=await r.json(); if(!r.ok) throw new Error(o.error); msg.textContent='Message envoyé. LDLJ pourra vous répondre à l’adresse indiquée.'; form.reset(); }catch(e){ msg.textContent=e.message||'Impossible d’envoyer le message.'; }
}
async function submitMembership(event){
 event.preventDefault(); const form=event.currentTarget,msg=document.getElementById('membershipMsg'); msg.textContent='Enregistrement en cours…';
 try{ const data={...Object.fromEntries(new FormData(form).entries()),programme:'Adhésion membre'}; const r=await fetch(`${API_BASE}/applications`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); const o=await r.json(); if(!r.ok) throw new Error(o.error); data.reference=o.reference; msg.innerHTML=`<strong>Demande enregistrée.</strong><br>Référence membre/dossier : <strong>${escapeHtml(o.reference)}</strong>`; showReceipt('membershipReceipt',data,"Demande d'adhésion"); form.reset(); }catch(e){ msg.textContent=e.message||'Erreur.'; }
}
document.addEventListener('click',e=>{ if(e.target.matches('#menu a')) closeMenu(); });
