import { getStore } from '@netlify/blobs';

export const json = (body, status = 200) => ({
  statusCode: status,
  headers: { 'content-type': 'application/json; charset=utf-8' },
  body: JSON.stringify(body)
});

export const store = getStore('ldlj');

export async function readList(key) {
  return (await store.get(key, { type: 'json' })) || [];
}

export async function writeList(key, value) {
  await store.setJSON(key, value);
}

export function adminAuthorized(event) {
  const expected = process.env.ADMIN_TOKEN;
  const supplied = event.headers?.['x-admin-token'] || event.headers?.['X-Admin-Token'];
  return Boolean(expected && supplied && supplied === expected);
}

export function clean(v, max = 500) {
  return String(v ?? '').trim().slice(0, max);
}

export function makeReference(existing) {
  const year = new Date().getFullYear();
  let ref;
  do {
    const n = Math.floor(100000 + Math.random() * 900000);
    ref = `LDLJ-${year}-${n}`;
  } while (existing.some(x => x.reference === ref));
  return ref;
}
