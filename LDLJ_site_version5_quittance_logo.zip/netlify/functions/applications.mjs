import { json, readList, writeList, clean, makeReference } from './_helpers.mjs';

export default async (event) => {
  if (event.httpMethod !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405);
  try {
    const body = JSON.parse(event.body || '{}');
    const nom = clean(body.nom, 160);
    const telephone = clean(body.telephone, 40);
    const email = clean(body.email, 160);
    const programme = clean(body.programme, 120);
    const dateNaissance = clean(body.dateNaissance, 20);
    const codeConfidentiel = clean(body.codeConfidentiel, 80);
    if (!nom || !telephone || !email || !programme) return json({ error: 'Veuillez remplir les champs obligatoires.' }, 400);
    const applications = await readList('applications');
    const reference = makeReference(applications);
    const item = {
      reference, nom, telephone, email, programme, dateNaissance, codeConfidentiel,
      created_at: new Date().toISOString(), status: 'En attente'
    };
    applications.unshift(item);
    await writeList('applications', applications.slice(0, 5000));
    return json({ ok: true, reference });
  } catch (e) {
    return json({ error: 'Impossible d’enregistrer la candidature.' }, 500);
  }
};
