import { json, readList, clean } from './_helpers.mjs';
export default async (event) => {
  if (event.httpMethod !== 'GET') return json({ error: 'Méthode non autorisée.' }, 405);
  const reference = clean(event.queryStringParameters?.reference, 40).toUpperCase();
  if (!reference) return json({ error: 'Référence manquante.' }, 400);
  const results = await readList('results');
  const result = results.find(r => r.reference === reference && r.published);
  if (!result) return json({ error: 'Aucun résultat publié pour cette référence.' }, 404);
  return json(result);
};
