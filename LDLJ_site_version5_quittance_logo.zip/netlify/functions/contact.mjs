import { json, readList, writeList, clean } from './_helpers.mjs';
export default async (event) => {
  if (event.httpMethod !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405);
  try {
    const body = JSON.parse(event.body || '{}');
    const nom = clean(body.nom, 160), email = clean(body.email, 160), message = clean(body.message, 2000);
    if (!nom || !email || !message) return json({ error: 'Veuillez remplir tous les champs.' }, 400);
    const messages = await readList('messages');
    messages.unshift({ id: crypto.randomUUID(), nom, email, message, created_at: new Date().toISOString(), status: 'Nouveau' });
    await writeList('messages', messages.slice(0, 5000));
    return json({ ok: true });
  } catch { return json({ error: 'Impossible d’enregistrer le message.' }, 500); }
};
