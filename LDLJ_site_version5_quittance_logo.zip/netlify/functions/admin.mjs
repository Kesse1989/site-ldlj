import { json, readList, writeList, adminAuthorized, clean } from './_helpers.mjs';

export default async (event) => {
  if (!adminAuthorized(event)) return json({ error: 'Accès administrateur refusé.' }, 401);
  try {
    const applications = await readList('applications');
    const messages = await readList('messages');
    const results = await readList('results');
    if (event.httpMethod === 'GET') return json({ applications, messages, results });
    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      const reference = clean(body.reference, 40).toUpperCase();
      const name = clean(body.name, 160), program = clean(body.program, 120), score = clean(body.score, 30), status = clean(body.status, 80);
      if (!reference) return json({ error: 'Référence obligatoire.' }, 400);
      const existing = results.findIndex(r => r.reference === reference);
      const item = { reference, name, program, score, status: status || 'Admis', published: Boolean(body.published), published_at: body.published ? new Date().toISOString() : null };
      if (existing >= 0) results[existing] = { ...results[existing], ...item }; else results.unshift(item);
      await writeList('results', results.slice(0, 5000));
      return json({ ok: true, result: item });
    }
    return json({ error: 'Méthode non autorisée.' }, 405);
  } catch { return json({ error: 'Erreur administrateur.' }, 500); }
};
